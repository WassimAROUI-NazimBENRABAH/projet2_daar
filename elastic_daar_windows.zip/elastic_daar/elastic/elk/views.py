from django.shortcuts import render
from elk.utils import *
from django.core.files.storage import FileSystemStorage
from elasticsearch import Elasticsearch
from django.views.generic.base import TemplateView
from django.conf import settings
import logging
from logstash_async.handler import AsynchronousLogstashHandler
import time


class Home(TemplateView):
    template_name = 'interface.html'



def logs_daar(message):
    host ='localhost'
    port = 5000

    test_logger = logging.getLogger('logging-LHOM-ELK')
    test_logger.setLevel(logging.DEBUG)

    async_handler = AsynchronousLogstashHandler(host,port,database_path=None)

    test_logger.addHandler(async_handler)

    test_logger.info(message)


def indexer(request):
    resp="Indexing Failed !"
    elastic=Elasticsearch(hosts=["elastic:changeme@127.0.0.1"])
    if request.method == "POST":
        uploaded_file = request.FILES['document']
        fs = FileSystemStorage()
        name = fs.save(uploaded_file.name, uploaded_file)
        if (name):
            logs_daar("File :"+name+" uploaded successfully")
        else:
            logs_daar("Failed to upload file")
        path=settings.MEDIA_ROOT+'\\'+name
    #if uploaded_file.is_valid():
        text=extract(path)
        if (text):
            logs_daar("Creating json file from "+ name +" ...")
        else:
            logs_daar("Failed to extract path of uploaded file")

        ind=text_json(text)
        if (ind):
            logs_daar("Json file created successfully from "+ name)
        else:
            logs_daar('Failed to create json file from : '+name)
        response = elastic.index(index='cv', doc_type='CV', document=ind)
        if (response):
            resp="Indexing Succeed !"
            logs_daar("Indexing data succeed")
        else:
            logs_daar('Failed to index data')
    else:
        form = upload()
    return render(request, 'indexing.html', {'resp': resp})
# Create your views here.

